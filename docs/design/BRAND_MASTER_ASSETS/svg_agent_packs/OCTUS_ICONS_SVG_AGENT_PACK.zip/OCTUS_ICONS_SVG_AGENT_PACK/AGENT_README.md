# OCTUS Icons — SVG Agent Pack

## Conteúdo

- `33` arquivos SVG autossuficientes em `svg_exact/`.
- PNGs originais preservados em `original_png/`.
- `manifest.csv` com dimensões, proporção, transparência, hashes e resultados de QA.
- `previews/icons_contact_sheet.jpg` para revisão rápida.
- `qa_renders/` com cada SVG renderizado novamente no tamanho original para validação.

## Método usado

Cada SVG contém o PNG original incorporado em base64, na resolução nativa e na mesma proporção. O SVG usa:

- `viewBox="0 0 largura altura"`;
- `preserveAspectRatio="xMidYMid meet"`;
- a imagem em `x=0`, `y=0`, com largura e altura originais;
- transparência original preservada;
- nenhuma compactação adicional;
- nenhum recorte;
- nenhum esticamento;
- nenhum trace automático.

Este é o método mais seguro para **não deformar nem alterar visualmente** ativos rasterizados ao entregá-los como arquivos `.svg`.

## Regra para o Agent

Use `svg_exact/` como fonte visual padrão.

Ao redimensionar:

- altere apenas `width` ou apenas `height`, ou mantenha a proporção travada;
- nunca use `preserveAspectRatio="none"`;
- não recorte o `viewBox`;
- não aplique filtros de nitidez, blur ou recoloração;
- não tente editar as cores por CSS: o conteúdo é raster incorporado;
- não converta novamente para JPEG.

## Limitação honesta

Os arquivos originais são PNG. Portanto, estes SVGs preservam a aparência e a qualidade original, mas não transformam automaticamente cada desenho em paths vetoriais editáveis. Um trace automático poderia deformar curvas, alterar espessuras e reduzir fidelidade. Para edição por nós e paths, é necessário reconstruir manualmente um vetor mestre ou obter os arquivos vetoriais originais.

## QA

O `manifest.csv` registra a comparação entre cada PNG original e o SVG renderizado em 1:1. A conversão é aprovada somente quando dimensões, proporção, canvas e transparência permanecem preservados.
